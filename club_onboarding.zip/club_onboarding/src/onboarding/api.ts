// Odysc club onboarding: every Supabase call the flow makes. No UI here.
// Pass in the supabase client your app already creates with the publishable/anon key.
import type { PostgrestError, SupabaseClient } from '@supabase/supabase-js';
import type {
  ClubSummary, InviteResult, OnboardingRequest, PendingInvite, ProfileForm,
} from './types';
import { emptyProfile, normalizeEmail } from './validation';

export class OnboardingError extends Error {}

function fail(err: PostgrestError | Error | null, fallback: string): never {
  if (err && 'code' in err && err.code === '42501')
    throw new OnboardingError('You don’t have permission to do that. Try signing in again.');
  throw new OnboardingError(err?.message || fallback);
}

const CLUB_COLUMNS = 'club_id, Name, Website, status';

function escapeLike(s: string): string {
  return s.replace(/[\\%_]/g, (c) => `\\${c}`);
}

// ---------- Auth (USC email + 6-digit code) ----------

export async function sendSignInCode(supabase: SupabaseClient, email: string): Promise<void> {
  const { error } = await supabase.auth.signInWithOtp({
    email: normalizeEmail(email),
    options: { shouldCreateUser: true },
  });
  if (error) fail(error, 'Could not send the code.');
}

export async function verifySignInCode(supabase: SupabaseClient, email: string, code: string): Promise<void> {
  const { error } = await supabase.auth.verifyOtp({
    email: normalizeEmail(email), token: code.trim(), type: 'email',
  });
  if (error) fail(error, 'That code didn’t work.');
}

// ---------- Find a club (the "is it listed on Odysc?" check) ----------

export async function searchClubs(supabase: SupabaseClient, query: string, limit = 10): Promise<ClubSummary[]> {
  const q = query.trim();
  if (q.length < 2) return [];
  const { data, error } = await supabase
    .from('clubs')
    .select(CLUB_COLUMNS)
    .ilike('Name', `%${escapeLike(q)}%`)
    .in('status', ['listed', 'active'])
    .order('Name')
    .limit(limit);
  if (error) fail(error, 'Search failed.');
  return (data ?? []) as ClubSummary[];
}

/** Used before creating a new club, to catch duplicates of listed ones ("AI Collective" vs "AI Collective at USC"). */
export async function findSimilarClubs(supabase: SupabaseClient, name: string): Promise<ClubSummary[]> {
  const words = name.toLowerCase().split(/[^a-z0-9]+/)
    .filter((w) => w.length > 3 && !['club', 'society', 'association', 'organization'].includes(w));
  if (words.length === 0) return searchClubs(supabase, name, 5);
  let q = supabase.from('clubs').select(CLUB_COLUMNS).in('status', ['listed', 'active']).limit(5);
  for (const w of words.slice(0, 3)) q = q.ilike('Name', `%${escapeLike(w)}%`);
  const { data, error } = await q;
  if (error) fail(error, 'Duplicate check failed.');
  return (data ?? []) as ClubSummary[];
}

// ---------- Prefill (verified path) ----------

export async function loadTagOptions(supabase: SupabaseClient): Promise<string[]> {
  const { data, error } = await supabase.from('tags').select('name').order('name');
  if (error) fail(error, 'Could not load tags.');
  return (data ?? []).map((t: { name: string }) => t.name);
}

export async function loadProfileForClub(
  supabase: SupabaseClient, club: ClubSummary, presidentEmail: string,
): Promise<ProfileForm> {
  const [profile, tags] = await Promise.all([
    supabase.from('club_profiles').select('*').eq('club_id', club.club_id).maybeSingle(),
    supabase.from('club_tags').select('tags(name)').eq('club_id', club.club_id),
  ]);
  if (profile.error) fail(profile.error, 'Could not load the club profile.');
  if (tags.error) fail(tags.error, 'Could not load the club’s tags.');

  const p = profile.data;
  const base = emptyProfile();
  return {
    ...base,
    clubName: club.Name,
    website: club.Website ?? '',
    // The president becomes the contact by default; seeded contacts are placeholders.
    eboardContactName: '',
    eboardContactRole: 'President',
    eboardContactEmail: normalizeEmail(presidentEmail),
    description: p?.description ?? '',
    memberSize: p?.member_size ?? '',
    timeCommitmentMin: p?.time_commitment_min?.toString() ?? '',
    timeCommitmentMax: p?.time_commitment_max?.toString() ?? '',
    meetingSchedule: p?.meeting_schedule ?? '',
    tags: (tags.data ?? [])
      .map((row: { tags: { name: string } | { name: string }[] | null }) =>
        Array.isArray(row.tags) ? row.tags[0]?.name : row.tags?.name)
      .filter((n): n is string => Boolean(n)),
  };
}

// ---------- Submit (both paths end in an admin-reviewed request) ----------

function toProposedProfile(f: ProfileForm) {
  return {
    eboard_contact_name: f.eboardContactName.trim(),
    eboard_contact_role: f.eboardContactRole.trim(),
    eboard_contact_email: normalizeEmail(f.eboardContactEmail),
    description: f.description.trim(),
    member_size: f.memberSize,
    time_commitment_min: Number(f.timeCommitmentMin),
    time_commitment_max: Number(f.timeCommitmentMax),
    meeting_schedule: f.meetingSchedule.trim(),
  };
}

async function insertRequest(
  supabase: SupabaseClient, userId: string, clubId: number, type: 'claim' | 'new_club', f: ProfileForm,
): Promise<OnboardingRequest> {
  const { data, error } = await supabase
    .from('onboarding_requests')
    .insert({
      club_id: clubId, user_id: userId, type,
      proposed_profile: toProposedProfile(f), proposed_tags: f.tags,
    })
    .select('id, club_id, type, status, admin_note, created_at')
    .single();
  if (error?.code === '23505') throw new OnboardingError('You already have a request in review for this club.');
  if (error?.code === '42501')
    throw new OnboardingError('This club can’t be claimed. It may already have a president on Odysc.');
  if (error) fail(error, 'Could not submit your request.');
  return data as OnboardingRequest;
}

/** Verified path: the club is listed, the president confirmed or edited its profile. */
export function submitClaim(supabase: SupabaseClient, userId: string, clubId: number, f: ProfileForm) {
  return insertRequest(supabase, userId, clubId, 'claim', f);
}

/** Not-verified path: create the club as pending (hidden from students), then the request. */
export async function submitNewClub(supabase: SupabaseClient, userId: string, f: ProfileForm): Promise<OnboardingRequest> {
  // Reuse a pending club this user already created (e.g. a previous attempt failed halfway).
  const existing = await supabase
    .from('clubs').select('club_id')
    .eq('created_by', userId).eq('status', 'pending_review').ilike('Name', escapeLike(f.clubName.trim()))
    .maybeSingle();
  if (existing.error) fail(existing.error, 'Could not check your existing clubs.');

  let clubId = existing.data?.club_id as number | undefined;
  if (!clubId) {
    const { data, error } = await supabase
      .from('clubs')
      .insert({
        Name: f.clubName.trim(),
        Website: f.website.trim() || null,
        status: 'pending_review',
        source: 'president_created',
        created_by: userId,
      })
      .select('club_id')
      .single();
    if (error) fail(error, 'Could not create the club.');
    clubId = data.club_id as number;
  }
  return insertRequest(supabase, userId, clubId, 'new_club', f);
}

// ---------- Resume where the user left off ----------

export interface UserOnboardingState {
  leaderOf: ClubSummary | null;
  latestRequest: (OnboardingRequest & { clubName: string }) | null;
  pendingInvites: PendingInvite[];
}

export async function loadUserState(supabase: SupabaseClient, userId: string, email: string): Promise<UserOnboardingState> {
  const [member, request, invites] = await Promise.all([
    supabase.from('club_members')
      .select(`role, clubs(${CLUB_COLUMNS})`)
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(1).maybeSingle(),
    supabase.from('onboarding_requests')
      .select('id, club_id, type, status, admin_note, created_at, clubs(Name)')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(1).maybeSingle(),
    supabase.from('club_invites')
      .select('id, club_id, clubs(Name)')
      .eq('email', normalizeEmail(email)).eq('status', 'pending'),
  ]);
  if (member.error) fail(member.error, 'Could not load your clubs.');
  if (request.error) fail(request.error, 'Could not load your requests.');
  if (invites.error) fail(invites.error, 'Could not load your invites.');

  const one = <T,>(v: T | T[] | null | undefined): T | null => (Array.isArray(v) ? v[0] ?? null : v ?? null);
  const r = request.data as (OnboardingRequest & { clubs: unknown }) | null;

  return {
    leaderOf: one(member.data?.clubs as ClubSummary | ClubSummary[] | null),
    latestRequest: r
      ? { ...r, clubName: one(r.clubs as { Name: string } | { Name: string }[] | null)?.Name ?? '' }
      : null,
    pendingInvites: (invites.data ?? []).map((i: { id: number; club_id: number; clubs: unknown }) => ({
      id: i.id,
      club_id: i.club_id,
      clubName: one(i.clubs as { Name: string } | { Name: string }[] | null)?.Name ?? '',
    })),
  };
}

// ---------- After approval: e-board invites ----------

export async function sendInvites(
  supabase: SupabaseClient, userId: string, clubId: number, emails: string[],
): Promise<InviteResult[]> {
  const results: InviteResult[] = [];
  for (const email of emails) {
    const { error } = await supabase.from('club_invites').insert({ club_id: clubId, email, invited_by: userId });
    if (!error) results.push({ email, ok: true });
    else if (error.code === '23505') results.push({ email, ok: false, error: 'Already invited' });
    else results.push({ email, ok: false, error: error.message });
  }
  return results;
}

export async function respondToInvite(
  supabase: SupabaseClient, userId: string, invite: PendingInvite, accept: boolean,
): Promise<void> {
  if (accept) {
    // Membership first: the policy only allows it while the invite is still pending.
    const { error } = await supabase
      .from('club_members').insert({ club_id: invite.club_id, user_id: userId, role: 'eboard' });
    if (error && error.code !== '23505') fail(error, 'Could not join the club.');
  }
  const { error } = await supabase
    .from('club_invites')
    .update({ status: accept ? 'accepted' : 'declined', responded_at: new Date().toISOString() })
    .eq('id', invite.id);
  if (error) fail(error, 'Could not update the invite.');
}

// ---------- Later edits by an approved president or e-board member ----------

export async function saveProfile(supabase: SupabaseClient, clubId: number, f: ProfileForm, tagIdsByName: Map<string, number>) {
  const { error } = await supabase
    .from('club_profiles')
    .upsert({ club_id: clubId, ...toProposedProfile(f), updated_at: new Date().toISOString() });
  if (error) fail(error, 'Could not save the profile.');

  const del = await supabase.from('club_tags').delete().eq('club_id', clubId);
  if (del.error) fail(del.error, 'Could not update tags.');
  const rows = f.tags.map((n) => tagIdsByName.get(n)).filter((id): id is number => id !== undefined)
    .map((tag_id) => ({ club_id: clubId, tag_id }));
  if (rows.length) {
    const ins = await supabase.from('club_tags').insert(rows);
    if (ins.error) fail(ins.error, 'Could not update tags.');
  }
}

// ---------- Admin ----------

export async function listPendingRequests(supabase: SupabaseClient) {
  const { data, error } = await supabase
    .from('onboarding_requests')
    .select('id, type, created_at, proposed_profile, proposed_tags, user_id, clubs(club_id, Name, Website, status)')
    .eq('status', 'pending').order('created_at');
  if (error) fail(error, 'Could not load requests.');
  return data ?? [];
}

export async function reviewRequest(supabase: SupabaseClient, requestId: number, approve: boolean, note?: string) {
  const { error } = await supabase.rpc('review_onboarding_request', {
    p_request_id: requestId, p_approve: approve, p_note: note ?? null,
  });
  if (error) fail(error, 'Could not review the request.');
}
