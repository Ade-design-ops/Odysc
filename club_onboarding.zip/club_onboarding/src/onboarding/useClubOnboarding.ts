// Odysc club onboarding: React hook that runs the whole flow.
// Your screens read `state` and call the actions. No markup here, so it drops into any design.
import { useCallback, useEffect, useReducer, useRef } from 'react';
import type { SupabaseClient, User } from '@supabase/supabase-js';
import * as api from './api';
import type {
  ClubSummary, InviteResult, OnboardingRequest, PendingInvite, ProfileErrors, ProfileForm, Step,
} from './types';
import { emptyProfile, isUscEmail, normalizeEmail, parseInviteEmails, validateProfile } from './validation';

export interface OnboardingState {
  step: Step;
  busy: boolean;
  error: string | null;           // banner-level error for the current screen
  notice: string | null;          // e.g. "Code sent to …", "Your last request was not approved: …"
  user: User | null;
  email: string;                  // sign-in email as typed
  searchQuery: string;
  searchResults: ClubSummary[];
  selectedClub: ClubSummary | null;
  form: ProfileForm;
  fieldErrors: ProfileErrors;
  tagOptions: string[];
  similarClubs: ClubSummary[];    // shown as "Is your club one of these?" before creating
  request: (OnboardingRequest & { clubName?: string }) | null;
  leaderOf: ClubSummary | null;
  invites: PendingInvite[];       // invites this user has received
  inviteResults: InviteResult[];  // results of invites this user sent
}

const initial: OnboardingState = {
  step: 'loading', busy: false, error: null, notice: null, user: null, email: '',
  searchQuery: '', searchResults: [], selectedClub: null, form: emptyProfile(), fieldErrors: {},
  tagOptions: [], similarClubs: [], request: null, leaderOf: null, invites: [], inviteResults: [],
};

type Action =
  | { type: 'patch'; patch: Partial<OnboardingState> }
  | { type: 'field'; field: keyof ProfileForm; value: ProfileForm[keyof ProfileForm] }
  | { type: 'reset' };

function reducer(s: OnboardingState, a: Action): OnboardingState {
  switch (a.type) {
    case 'patch':
      return { ...s, ...a.patch };
    case 'field': {
      const fieldErrors = { ...s.fieldErrors };
      delete fieldErrors[a.field];
      return { ...s, form: { ...s.form, [a.field]: a.value }, fieldErrors };
    }
    case 'reset':
      return { ...initial, step: 'signIn' };
  }
}

export function useClubOnboarding(supabase: SupabaseClient) {
  const [state, dispatch] = useReducer(reducer, initial);
  const patch = useCallback((p: Partial<OnboardingState>) => dispatch({ type: 'patch', patch: p }), []);
  const searchSeq = useRef(0);

  /** Wraps an async action with busy/error handling so every screen behaves the same way. */
  const run = useCallback(async (fn: () => Promise<void>) => {
    patch({ busy: true, error: null });
    try {
      await fn();
    } catch (e) {
      patch({ error: e instanceof Error ? e.message : 'Something went wrong. Try again.' });
    } finally {
      patch({ busy: false });
    }
  }, [patch]);

  /** Decides which screen a signed-in user should see. Called on load, after sign-in, and by refresh(). */
  const resume = useCallback(async (user: User) => {
    const email = user.email ?? '';
    if (!isUscEmail(email)) {
      await supabase.auth.signOut();
      dispatch({ type: 'reset' });
      patch({ error: 'Odysc onboarding needs a @usc.edu email.' });
      return;
    }
    const s = await api.loadUserState(supabase, user.id, email);
    const base = { user, leaderOf: s.leaderOf, invites: s.pendingInvites, request: s.latestRequest };

    if (s.pendingInvites.length) return patch({ ...base, step: 'invites' });
    if (s.leaderOf) return patch({ ...base, step: 'inviteEboard' });
    if (s.latestRequest?.status === 'pending') return patch({ ...base, step: 'pendingApproval' });
    patch({
      ...base,
      step: 'findClub',
      notice: s.latestRequest?.status === 'rejected'
        ? `Your request for ${s.latestRequest.clubName} wasn’t approved${s.latestRequest.admin_note ? `: ${s.latestRequest.admin_note}` : '.'}`
        : null,
    });
  }, [supabase, patch]);

  // Restore an existing session on mount.
  useEffect(() => {
    let cancelled = false;
    supabase.auth.getUser().then(({ data }) => {
      if (cancelled) return;
      if (data.user) run(() => resume(data.user!));
      else patch({ step: 'signIn' });
    });
    return () => { cancelled = true; };
  }, [supabase, run, resume, patch]);

  // ---------- signIn / verifyCode ----------

  const setEmail = (email: string) => patch({ email, error: null });

  const sendCode = () => run(async () => {
    if (!isUscEmail(state.email)) throw new Error('Use your @usc.edu email.');
    await api.sendSignInCode(supabase, state.email);
    patch({ step: 'verifyCode', notice: `We sent a 6-digit code to ${normalizeEmail(state.email)}.` });
  });

  const verifyCode = (code: string) => run(async () => {
    await api.verifySignInCode(supabase, state.email, code);
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw new Error('Sign-in didn’t finish. Try again.');
    patch({ notice: null });
    await resume(data.user);
  });

  const signOut = () => run(async () => {
    await supabase.auth.signOut();
    dispatch({ type: 'reset' });
  });

  // ---------- findClub ----------

  /** Call on every keystroke; stale responses are ignored. Debounce in the UI if you like. */
  const search = (query: string) => {
    patch({ searchQuery: query });
    const seq = ++searchSeq.current;
    api.searchClubs(supabase, query)
      .then((results) => { if (seq === searchSeq.current) patch({ searchResults: results }); })
      .catch((e) => patch({ error: e.message }));
  };

  const ensureTags = async () => {
    if (state.tagOptions.length) return state.tagOptions;
    const tags = await api.loadTagOptions(supabase);
    patch({ tagOptions: tags });
    return tags;
  };

  /** "Verified" branch: the club is on Odysc. Prefill from Supabase so the president confirms or edits. */
  const selectClub = (club: ClubSummary) => run(async () => {
    if (club.status === 'active')
      throw new Error(`${club.Name} already has a president on Odysc. Ask them to invite you to the e-board.`);
    await ensureTags();
    const form = await api.loadProfileForClub(supabase, club, state.user?.email ?? '');
    patch({ selectedClub: club, form, fieldErrors: {}, similarClubs: [], step: 'reviewProfile' });
  });

  /** "Not verified" branch: the club isn't listed. Start an empty profile with the search text as its name. */
  const startNewClub = () => run(async () => {
    await ensureTags();
    patch({
      selectedClub: null,
      form: { ...emptyProfile(), clubName: state.searchQuery.trim(), eboardContactEmail: state.user?.email ?? '' },
      fieldErrors: {}, similarClubs: [], step: 'createClub',
    });
  });

  const backToSearch = () => patch({ step: 'findClub', error: null, similarClubs: [] });

  // ---------- reviewProfile / createClub (shared form) ----------

  const setField = <K extends keyof ProfileForm>(field: K, value: ProfileForm[K]) =>
    dispatch({ type: 'field', field, value });

  const toggleTag = (tag: string) =>
    setField('tags', state.form.tags.includes(tag)
      ? state.form.tags.filter((t) => t !== tag)
      : [...state.form.tags, tag]);

  /**
   * Submits either path. For a new club, the first call checks for similar listed clubs and stops
   * if it finds any (state.similarClubs). Call again with { skipDuplicateCheck: true } after the
   * president confirms their club isn't one of them.
   */
  const submit = (opts: { skipDuplicateCheck?: boolean } = {}) => run(async () => {
    const isNew = state.step === 'createClub';
    const errors = validateProfile(state.form, isNew);
    if (Object.keys(errors).length) {
      patch({ fieldErrors: errors, error: 'Fix the highlighted fields.' });
      return;
    }
    const user = state.user;
    if (!user) throw new Error('Your session ended. Sign in again.');

    let request: OnboardingRequest;
    if (isNew) {
      if (!opts.skipDuplicateCheck) {
        const similar = await api.findSimilarClubs(supabase, state.form.clubName);
        if (similar.length) {
          patch({ similarClubs: similar });
          return;
        }
      }
      request = await api.submitNewClub(supabase, user.id, state.form);
    } else {
      if (!state.selectedClub) throw new Error('Pick your club first.');
      request = await api.submitClaim(supabase, user.id, state.selectedClub.club_id, state.form);
    }
    patch({
      request: { ...request, clubName: state.form.clubName },
      similarClubs: [], fieldErrors: {}, step: 'pendingApproval',
    });
  });

  // ---------- pendingApproval ----------

  /** Re-checks approval status. Call from a "Check status" button or poll every ~30s on this screen. */
  const refresh = () => run(async () => {
    if (state.user) await resume(state.user);
  });

  // ---------- inviteEboard ----------

  const sendInvites = (rawEmails: string) => run(async () => {
    if (!state.user || !state.leaderOf) throw new Error('Your club isn’t approved yet.');
    const { valid, invalid } = parseInviteEmails(rawEmails, state.user.email);
    if (!valid.length && !invalid.length) throw new Error('Enter at least one @usc.edu email.');
    const sent = valid.length ? await api.sendInvites(supabase, state.user.id, state.leaderOf.club_id, valid) : [];
    patch({
      inviteResults: [...sent, ...invalid.map((email) => ({ email, ok: false, error: 'Not a @usc.edu email' }))],
    });
  });

  const finish = () => patch({ step: 'done' });

  // ---------- invites (for e-board members who were invited) ----------

  const respondToInvite = (invite: PendingInvite, accept: boolean) => run(async () => {
    if (!state.user) throw new Error('Your session ended. Sign in again.');
    await api.respondToInvite(supabase, state.user.id, invite, accept);
    const remaining = state.invites.filter((i) => i.id !== invite.id);
    patch({ invites: remaining });
    if (!remaining.length) await resume(state.user);
  });

  const dismissError = () => patch({ error: null });

  return {
    state,
    actions: {
      setEmail, sendCode, verifyCode, signOut,
      search, selectClub, startNewClub, backToSearch,
      setField, toggleTag, submit,
      refresh,
      sendInvites, finish,
      respondToInvite,
      dismissError,
    },
  };
}
