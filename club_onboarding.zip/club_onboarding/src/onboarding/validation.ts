// Odysc club onboarding: form validation. Pure functions, no UI or network.
import type { ProfileErrors, ProfileForm } from './types';

export const USC_EMAIL = /^[^\s@]+@usc\.edu$/i;
export const MEMBER_SIZES = ['Small', 'Medium', 'Large'] as const;
export const DESCRIPTION_MIN = 20;
export const DESCRIPTION_MAX = 500;
export const HOURS_MAX = 40;
export const TAGS_MIN = 1;
export const TAGS_MAX = 10; // imported clubs have up to 9 tags

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function isUscEmail(email: string): boolean {
  return USC_EMAIL.test(normalizeEmail(email));
}

export function emptyProfile(): ProfileForm {
  return {
    clubName: '',
    website: '',
    eboardContactName: '',
    eboardContactRole: 'President',
    eboardContactEmail: '',
    description: '',
    memberSize: '',
    timeCommitmentMin: '',
    timeCommitmentMax: '',
    meetingSchedule: '',
    tags: [],
  };
}

function wholeHours(v: string): number | null {
  if (!/^\d+$/.test(v.trim())) return null;
  const n = Number(v);
  return n >= 0 && n <= HOURS_MAX ? n : null;
}

/** Returns an empty object when the form is valid. `isNewClub` turns on club name/website checks. */
export function validateProfile(f: ProfileForm, isNewClub: boolean): ProfileErrors {
  const e: ProfileErrors = {};

  if (isNewClub) {
    if (f.clubName.trim().length < 3) e.clubName = 'Enter your club’s full name.';
    if (f.website.trim() && !/^https?:\/\/\S+\.\S+/.test(f.website.trim()))
      e.website = 'Enter a full link starting with http:// or https://';
  }

  if (!f.eboardContactName.trim()) e.eboardContactName = 'Enter a contact name.';
  if (!f.eboardContactRole.trim()) e.eboardContactRole = 'Enter the contact’s role.';
  if (!isUscEmail(f.eboardContactEmail)) e.eboardContactEmail = 'Use a @usc.edu email.';

  const d = f.description.trim().length;
  if (d < DESCRIPTION_MIN) e.description = `Write at least ${DESCRIPTION_MIN} characters.`;
  else if (d > DESCRIPTION_MAX) e.description = `Keep it under ${DESCRIPTION_MAX} characters.`;

  if (!MEMBER_SIZES.includes(f.memberSize as (typeof MEMBER_SIZES)[number]))
    e.memberSize = 'Pick a member size.';

  const lo = wholeHours(f.timeCommitmentMin);
  const hi = wholeHours(f.timeCommitmentMax);
  if (lo === null) e.timeCommitmentMin = `Enter whole hours from 0 to ${HOURS_MAX}.`;
  if (hi === null) e.timeCommitmentMax = `Enter whole hours from 0 to ${HOURS_MAX}.`;
  if (lo !== null && hi !== null && hi < lo)
    e.timeCommitmentMax = 'Maximum must be at least the minimum.';

  if (!f.meetingSchedule.trim()) e.meetingSchedule = 'Say when the club meets.';

  if (f.tags.length < TAGS_MIN) e.tags = 'Pick at least one interest tag.';
  else if (f.tags.length > TAGS_MAX) e.tags = `Pick at most ${TAGS_MAX} tags.`;

  return e;
}

/** Splits a pasted list ("a@usc.edu, b@usc.edu\nc@usc.edu") into valid and invalid emails, de-duplicated. */
export function parseInviteEmails(raw: string, selfEmail?: string): { valid: string[]; invalid: string[] } {
  const self = selfEmail ? normalizeEmail(selfEmail) : '';
  const seen = new Set<string>();
  const valid: string[] = [];
  const invalid: string[] = [];
  for (const part of raw.split(/[\s,;]+/)) {
    const email = normalizeEmail(part);
    if (!email || seen.has(email) || email === self) continue;
    seen.add(email);
    (isUscEmail(email) ? valid : invalid).push(email);
  }
  return { valid, invalid };
}
