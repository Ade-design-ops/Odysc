// Odysc club onboarding: shared types.

export type ClubStatus = 'listed' | 'pending_review' | 'active' | 'rejected';
export type MemberSize = 'Small' | 'Medium' | 'Large';
export type RequestStatus = 'pending' | 'approved' | 'rejected';

export interface ClubSummary {
  club_id: number;
  Name: string;
  Website: string | null;
  status: ClubStatus;
}

/** Everything the president fills in or confirms. Field names match the form, not the database. */
export interface ProfileForm {
  clubName: string;          // only editable when creating a new club
  website: string;           // only editable when creating a new club
  eboardContactName: string;
  eboardContactRole: string;
  eboardContactEmail: string;
  description: string;
  memberSize: MemberSize | '';
  timeCommitmentMin: string; // strings so inputs can be empty while typing
  timeCommitmentMax: string;
  meetingSchedule: string;
  tags: string[];
}

export type ProfileErrors = Partial<Record<keyof ProfileForm, string>>;

export interface OnboardingRequest {
  id: number;
  club_id: number;
  type: 'claim' | 'new_club';
  status: RequestStatus;
  admin_note: string | null;
  created_at: string;
}

export interface PendingInvite {
  id: number;
  club_id: number;
  clubName: string;
}

export interface InviteResult {
  email: string;
  ok: boolean;
  error?: string;
}

/**
 * One value per screen in the flow diagram. Map each to a screen in your design.
 *
 * signIn ─► verifyCode ─► findClub ─┬─(club is listed)─────► reviewProfile ─┐
 *                                   └─(not listed)──────────► createClub ───┤
 *                                                                            ▼
 *                       inviteEboard ◄─(admin approves)── pendingApproval ◄──┘
 *                            │
 *                            ▼
 *                          done
 *
 * invites: shown instead when someone signs in with a pending e-board invite.
 */
export type Step =
  | 'loading'
  | 'signIn'
  | 'verifyCode'
  | 'findClub'
  | 'reviewProfile'
  | 'createClub'
  | 'pendingApproval'
  | 'inviteEboard'
  | 'invites'
  | 'done';
